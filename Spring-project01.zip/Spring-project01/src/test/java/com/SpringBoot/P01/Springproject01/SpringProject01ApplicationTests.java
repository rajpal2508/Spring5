package com.SpringBoot.P01.Springproject01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProject01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
