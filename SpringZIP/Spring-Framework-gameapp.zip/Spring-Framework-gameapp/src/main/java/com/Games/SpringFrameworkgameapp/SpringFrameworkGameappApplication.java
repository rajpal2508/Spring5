package com.Games.SpringFrameworkgameapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFrameworkGameappApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFrameworkGameappApplication.class, args);
	}

}
